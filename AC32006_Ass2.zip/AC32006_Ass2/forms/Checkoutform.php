<form action="signUPpage.php" method="post">

		Username:<br />
		<input name="username" type="text" /><br />
	
		First name:<br />
		<input name="firstName" type="text" /><br />
	
		Last name:<br />
		<input name="lastName" type="text" /><br />
	
		Phone Number:<br />
		<input name="phoneNumber" type="numeric" /><br /> 

		Email:<br />
		<input name="email" type="email" /><br />

		Password:<br />
		<input name="passwords" type="password" /><br />
		
		Password repeat:<br />
		<input name="passwordRepeat" type="password" /><br />

		Data of Birth: <br />
		<input name="dateofbirth" type="date" /><br />

		<input type="submit" />

	</form>