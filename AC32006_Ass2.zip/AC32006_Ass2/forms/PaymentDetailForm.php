<form action="PaymentDetails.php" method="post">

		Account name:<br />
		<input name="name" type="text" /><br />
	
		Card number:<br />
		<input name="number" type="text" /><br />
	
		Cardholder Address:<br />
		<input name="add" type="text" /><br />
	
		Expiration Date:<br />
		<input name="expDate" type="date" /><br />

		<input type="submit" />

</form>