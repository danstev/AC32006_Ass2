<form action="addSupplier.php" method="post">

		Supplier name:<br />
		<input name="supplier" type="text" /><br />

		Email:<br />
		<input name="email" type="text" /><br />

		Phone number:<br />
		<input name="phoneNumber" type="text" /><br />
	

		<input type="submit" />

	</form>