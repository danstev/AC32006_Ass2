<form action="signUPpage.php" method="post">

		Order ID:<br />
		<input name="orderID" type="text" /><br />
	

		Complaint:<br />
		<input name="complaint" type="text" rows="5" cols="80" /><br />


		<input type="submit" />

	</form>