<form action="signUPpage.php" method="post">

		Postcode :<br />
		<input name="PostCode" type="text" /><br />
	
		Street :<br />
		<input name="street" type="text" /><br />
	
		House number :<br />
		<input name="houseNo" type="numeric" /><br /> 
		
		City :<br />
		<input name="city" type="text" /><br />
		
		County :<br />
		<input name="county" type="text" /><br />


		<input type="submit" />

	</form>