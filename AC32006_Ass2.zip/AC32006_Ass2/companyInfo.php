<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="style.css">

<html>
<title> </title>
<body>
	<h1>   DiveMasters</h1>


	<article>
	<h2> General Company Information</h2>
	<p>DiveMasters is a British company that sells a variety of scuba diving gear to the general public through its six branches and it’s online e-shop. The
company is also the official seller of the suppliers Mares and Cressi. The head
office of DiveMasters is in Edinburgh along with one of its four warehouses.</p>
	</article>
<p>The different verieties of products that the company sell includes:</p>
 <ul>
      <li>Masks</li>
      <li>Fins</li>
      <li>BCDs</li>
      <li>Regulators</li>
       <li>Wetsuits</li>
      <li>Snorkels</li>
      <li>Dive Computers</li>
      <li>Scuba Cylinders</li>
    </ul>

 <h2> Our Stores </h2>

 <p>If you are not about a particular product you can either email us or visit one of our six branches where one of our employees will help you. Two of our branches are located in Edinburgh, one in Glasgow one in Dundee, one in St Andrews and one in Aberdeen.</p>

 <p>All our stores operate the same hours which are: </p>
 <ul>
      <li>Monday	09:00 – 18:00</li>
      <li>Tuesday	09:00 – 18:00</li>
      <li>Wednesday	09:00 – 18:00</li>
      <li>Thursday	09:00 – 18:00</li>
       <li>Friday	09:00 – 18:00</li>
      <li>Saturday	09:00 – 17:00</li>
      <li>Sunday	10:00 – 16:00</li>
    </ul>
 











</body>

</html>