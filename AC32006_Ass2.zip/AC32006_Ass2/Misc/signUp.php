<!-- start example form for signUp page which is will be connected to user_accounts table
-->

<form action="signup.php" method="post">

	Username:<br />
	<input name="username" type="text" /><br />

	Password:<br />
	<input name="password" type="password" /><br />

	Email:<br />
	<input name="email" type="text" /><br />

	Data of Birth: <br />
	<input name="dateofbirth" type="date" /><br />

	<input type="submit" />

</form>