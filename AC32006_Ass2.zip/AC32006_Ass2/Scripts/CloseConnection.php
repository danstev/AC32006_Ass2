<?php
	//Some if checks here will be nice
	mysql_close($db);
?>