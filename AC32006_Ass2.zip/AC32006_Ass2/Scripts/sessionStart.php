<?php

	if(session_id() === '')
		{
			session_start();
			if(!isset($_SESSION["privilege"]))
			{
				$_SESSION["privilege"] = '';
			}

		}

?> 