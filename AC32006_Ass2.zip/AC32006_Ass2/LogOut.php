<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="style.css">

<html>
<title>Logout : ScubaDivers </title>
<body>
	<?php include 'header.php';?>
<<<<<<< HEAD
	<?php include 'scripts/sessionStart.php';?>
=======
>>>>>>> bb1cfb2ea72dc3afa70887398d5f220ddb4750c1
	<h1>Log out : Scubadiver bullshit what did we call us?</h1>

	<article>
	<h2>Logged out</h2>
	<p>Come back soon!</p>
	<?php include 'scripts/sessionEnd.php';?>
	</article>
		
	<?php include 'footer.php';?>

</body>

</html>
